<?php
$wishes = ['счастья','здоровья','воображения'];
$epithets = ['бесконечного','постоянного','классного'];
$random_congr = [];

$name = readline("Ваше имя:");

$name = ucfirst($name);
$number = 2;

for($i = 0; $i < $number; $i++){
    $randWishes = array_rand($wishes);
    $randEpithets = array_rand($epithets);
    
    $random_congr[] = $epithets[$randEpithets] . ' ' . $wishes[$randWishes];
    
    unset($wishes[$randWishes]);
    unset($epithets[$randEpithets]);  
}

$last = ' и ' . array_pop($random_congr);
$string_cong = implode(", ", $random_congr) . $last;

echo "$name, поздравляем тебя с Днем Рожденья, желаю $string_cong ";

